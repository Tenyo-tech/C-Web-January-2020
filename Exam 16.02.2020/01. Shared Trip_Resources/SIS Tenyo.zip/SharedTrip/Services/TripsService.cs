﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using SharedTrip.Models;
using SharedTrip.ViewModels.Trips;

namespace SharedTrip.Services
{
    public class TripsService :ITripsService
    {
        private readonly ApplicationDbContext db;

        public TripsService(ApplicationDbContext db)
        {
            this.db = db;
        }
        public string Add(AddTripModel model)
        //(string startPoint,string endPoint,DateTime departureTime,
        //    int seats,string description,string imagePath)
        {

            var trip = new Trip
            {
                StartPoint = model.StartPoint,
                EndPoint = model.EndPoint,
                DepartureTime = DateTime.ParseExact(model.DepartureTime, "dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture),
                Seats = model.Seats,
                Description = model.Description,
                ImagePath = model.ImagePath,
            };
            db.Trips.Add(trip);
            db.SaveChanges();
            return trip.Id;
        }

        public IEnumerable<Trip> GetAll() 
            => this.db.Trips.Select(x => new Trip
            {
                Id = x.Id,
                StartPoint = x.StartPoint,
                EndPoint = x.EndPoint,
                DepartureTime = x.DepartureTime,
                Seats = x.Seats,
            })
            .ToArray();

        public Trip GetById(string id) => this.db.Trips.FirstOrDefault(x => x.Id == id);
        public void JoinById(string userId,string tripId)
        {
            var trip = this.GetById(tripId);
            var userTrip = new UserTrip
            {
                UserId = userId,
                TripId = tripId,
            };
            this.db.UserTrips.Add(userTrip);
            this.db.SaveChanges();
        }
    }
}
