﻿namespace SharedTrip
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString = @"Server=DESKTOP-QK1M4A0\SQLEXPRESS;Database=SharedTrip-Tenyo;Integrated Security=True;";
    }
}